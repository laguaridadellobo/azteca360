<?php

/*
Plugin Name: Azteca 360 Pasarela de pagos
Plugin URI: https://www.azteca360.com/
Description: Azteca 360 Pasarela de pago para Wordpress.
Version: 1.0
Author: Alberto Escobar developer
Author URI: www.linkedin.com/in/contactalbertoescobar
License: A "Slug" license name e.g. GPL2
License URI:       http://www.pordefinir.org/
Text Domain:       woocommerce-pasarela-azteca360
Domain Path:       /languages
*/


// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require dirname( __FILE__ ) . '/includes/class-azteca360.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_azteca360() {

	$plugin = new azteca360_WC();
	$plugin->run();

}
run_azteca360();




