<?php

use azteca360\lib\Amount;
use azteca360\lib\ExtraTaxes;
use azteca360\lib\azteca360;
use azteca360\lib\azteca360Environment;
use azteca360\lib\azteca360Language;
class WC_azteca360_Gateway extends WC_Payment_Gateway_CC {

	private $environment;
	private $private_id;
	private $public_id;
	private $tax_iva;
	private $tax_ice;
	private $tax_propina;
	private $tax_tasa_aeroportuaria;
	private $tax_agencia_viaje;
	private $color;
	

	public function __construct() {
		$this->id                 = "azteca360";
		$this->method_title       = __( "azteca360", 'azteca360-gateway' );
		$this->method_description = __( "azteca360 pasarela de pago para WooCommerce.", 'azteca360-gateway' );
		$this->title              = __( "azteca360", 'azteca360-gateway' );
		$this->color              = __( "azteca360", 'azteca360-gateway' );
		$this->icon               = apply_filters( 'woocommerce_azteca360_icon', plugins_url( '../assets/azteca360.png', __FILE__ ) );
		$this->has_fields         = true;
		$this->init_form_fields();
		$this->init_settings();
		add_action( 'admin_notices', array( $this, 'do_ssl_check' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );

		foreach ( $this->settings as $setting_key => $value ) {
			$this->$setting_key = $value;
		}
		// Lets check for SSL
		add_action('admin_notices', array($this, 'do_ssl_check'));
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array(
			$this,
			"process_admin_options"
		) );

	}

	public function do_ssl_check()
	{
		if ($this->enabled == "yes") {
			if (get_option('woocommerce_force_ssl_checkout') == "no") {
				echo "<div class=\"error\"><p>" . sprintf(__("<strong>%s</strong> está habilitado y WooCommerce no está forzando el certificado SSL en su página de pago. Asegúrese de tener un certificado SSL válido y de <a href=\"%s\">obligando a que las páginas de pago estén protegidas.</a>"), $this->method_title, admin_url('admin.php?page=wc-settings&tab=checkout')) . "</p></div>";
			}
		}
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'                => array(
				'title'   => __( 'Enable / Disable', 'azteca360-gateway' ),
				'label'   => __( 'Habilita esta pasarela de pago', 'azteca360-gateway' ),
				'type'    => 'checkbox',
				'default' => 'no',
			),
			'title'                  => array(
				'title'    => __( 'Titulo', 'azteca360-gateway' ),
				'type'     => 'text',
				'desc_tip' => __( 'Título de pago que verá el cliente durante el proceso de pago.', 'azteca360-gateway' ),
				'default'  => __( 'azteca360', 'azteca360-gateway' ),
			),
			'description'            => array(
				'title'    => __( 'Descripcion', 'azteca360-gateway' ),
				'type'     => 'textarea',
				'desc_tip' => __( 'Descripción del pago que verá el cliente durante el proceso de pago. ', 'azteca360-gateway' ),
				'default'  => __( 'Pay securely using your credit card.', 'azteca360-gateway' ),
				'css'      => 'max-width:350px;'
			),
			'public_id'              => array(
				'title'    => __( 'Identificación pública del comerciante', 'azteca360-gateway' ),
				'type'     => 'text',
				'desc_tip' => __( 'Esta es la identificación pública del comerciante proporcionada por azteca360.', 'azteca360-gateway' ),
			),
			'private_id'             => array(
				'title'    => __( 'Identificación privada del comerciante', 'azteca360-gateway' ),
				'type'     => 'password',
				'desc_tip' => __( 'Esta es la identificación privada del comerciante proporcionada por azteca360.', 'azteca360-gateway' ),
			),
			'environment'            => array(
				'title'       => __( 'Modo Prueba', 'azteca360-gateway' ),
				'label'       => __( 'Habilitar el modo de prueba', 'azteca360-gateway' ),
				'type'        => 'checkbox',
				'description' => __( 'Coloque la pasarela de pago en modo de prueba.', 'azteca360-gateway' ),
				'default'     => 'yes',
			),
			'tax_details'            => array(
				'title'       => __( 'Configuraciónes adicionales', 'azteca360-gateway' ),
				'type'        => 'title',
				'description' => __( "Establezca los parametros de .<br>" .
				                     "<strong>NOTA: Mantenga en blanco las configuraciones no utilizadas. </strong>", 'azteca360-gateway' ),
			),
			'color'                => array(
				'title'       => __( 'Color Pasarela', 'azteca360-gateway' ),
				'type'        => 'color',
				'description' => __( 'Define el color a su pasarela de pagos que mas le agrade .', 'azteca360-gateway' ),
				
			)
		);
	}

	public function process_payment( $order_id ) {
		$customer_order = wc_get_order( $order_id );

		$merchantId  = $this->private_id;
		$color 	     = $this->color;
		$language    = azteca360Language::ES;
		$currency    = $customer_order->get_currency();
		$decimals    = wc_get_price_decimals();
		$environment = ( $this->environment == "yes" ) ? azteca360Environment::TESTING : azteca360Environment::PRODUCTION;
		$dataOrder   = $customer_order->get_data();

		$azteca360 = new azteca360( $merchantId, $language, $currency, $environment );

		$token             = $_POST['azteca360Token'];
		$months            = intval( $_POST['azteca360Deferred'] );
		$iva               = 0;
		$ice               = 0;
		$propina           = null;
		$tasaAeroportuaria = null;
		$agenciaDeViaje    = null;
		$iac               = null;

		foreach ( $dataOrder['tax_lines'] as $tax ) {
			$totalTax = round( floatval( $tax->get_tax_total() ), $decimals );
			if ( $tax->get_shipping_tax_total() ) {
				$totalTax += round( floatval( $tax->get_shipping_tax_total() ), $decimals );
			}
			switch ( $tax->get_label() ) {
				case $this->tax_iva:
					$ivaPercent = intval( str_replace( '%', '', WC_Tax::get_rate_percent( $tax->get_rate_id() ) ) ) / 100;
					$iva        += $totalTax;
					break;
				case $this->tax_ice:
					$ice += $totalTax;
					break;
				case $this->tax_propina:
					if ( is_null( $propina ) ) {
						$propina = 0;
					}
					$propina += $totalTax;
					break;
				case $this->tax_tasa_aeroportuaria:
					if ( is_null( $tasaAeroportuaria ) ) {
						$tasaAeroportuaria = 0;
					}
					$tasaAeroportuaria += $totalTax;
					break;
				case $this->tax_agencia_viaje:
					if ( is_null( $agenciaDeViaje ) ) {
						$agenciaDeViaje = 0;
					}
					$agenciaDeViaje += $totalTax;
					break;
				case $this->tax_iac:
					if ( is_null( $iac ) ) {
						$iac = 0;
					}
					$iac += $totalTax;
					break;
			}
		}

		$subtotalIva  = 0;
		$subtotalIva0 = 0;

		foreach ( $customer_order->get_items() as $item_key => $item_values ) {
			$item_data   = $item_values->get_data();
			$product_tax = $item_data['subtotal_tax'];
			if ( $product_tax != 0 && $iva != 0 ) {
				$subtotalIva += $item_data['subtotal'];
			} else {
				$subtotalIva0 += $item_data['subtotal'];
			}
		}

		foreach ( $dataOrder['shipping_lines'] as $item_key => $item_values ) {
			$item_data = $item_values->get_data();
			if ( $item_data['total_tax'] != 0 ) {
				$shipping_value = round( floatval( $item_data['total'] ), $decimals );
				$subtotalIva    += $shipping_value;
			} else {
				$subtotalIva0 += round( floatval( $item_data['total'] ), $decimals );
			}
		}

		foreach ( $dataOrder['coupon_lines'] as $item_key => $item_values ) {
			$item_data = $item_values->get_data();
			if ( $item_data['discount_tax'] != 0 ) {
				$subtotalIva -= round( floatval( $item_data['discount'] ), $decimals );
			} else {
				$subtotalIva0 -= round( floatval( $item_data['discount'] ), $decimals );
			}
		}

		foreach ( $dataOrder['fee_lines'] as $item_key => $item_values ) {
			$item_data = $item_values->get_data();
			if ( $item_data['total_tax'] != 0 ) {
				$subtotalIva += round( floatval( $item_data['total'] ), $decimals );
			} else {
				$subtotalIva0 += round( floatval( $item_data['total'] ), $decimals );
			}
		}


		$iva = round( $iva, $decimals );

		$auxTax = $ice;

        $subtotalIva = round($subtotalIva,$decimals);
        $subtotalIva0 = round($subtotalIva0,$decimals);

		if ( ! is_null( $propina )
		     || ! is_null( $tasaAeroportuaria )
		     || ! is_null( $agenciaDeViaje )
		     || ! is_null( $iac ) ) {
			$auxTax = new ExtraTaxes( ( ! is_null( $propina ) ? round( $propina, $decimals ) : 0 ),
				( ! is_null( $tasaAeroportuaria ) ? round( $tasaAeroportuaria, $decimals ) : 0 ),
				( ! is_null( $agenciaDeViaje ) ? round( $agenciaDeViaje, $decimals ) : 0 ),
				( ! is_null( $iac ) ? round( $iac, $decimals ) : 0 ) );
		}

        $auxTax =round($auxTax,$decimals);

		$amount = new Amount( $subtotalIva, $iva, $subtotalIva0, $auxTax );

		$taxLines = [];
		foreach ( $dataOrder['tax_lines'] as $item ) {
			array_push( $taxLines, $item->get_data() );
		}
		$dataOrder['tax_lines'] = $taxLines;

		$shippingLines = [];
		foreach ( $dataOrder['shipping_lines'] as $item ) {
			array_push( $shippingLines, $item->get_data() );
		}
		$dataOrder['shipping_lines'] = $shippingLines;

		$feeLines = [];
		foreach ( $dataOrder['fee_lines'] as $item ) {
			array_push( $feeLines, $item->get_data() );
		}
		$dataOrder['fee_lines'] = $feeLines;
        $customer_contact_details = $this->build_contact_details($customer_order);

		unset( $dataOrder['coupon_lines'] );
		unset( $dataOrder['meta_data'] );
		unset( $dataOrder['line_items'] );

		if ( $months > 0 ) {
			$transaction = $azteca360->deferredCharge( $token, $amount, $months, $dataOrder, $customer_contact_details);
			// $transaction = $azteca360->deferredCharge($token, $amount, $months);
		} else {
			$transaction = $azteca360->charge( $token, $amount, $dataOrder, $customer_contact_details);
			// $transaction = $azteca360->charge($token, $amount);
		}

		if ( $transaction->isSuccessful() ) {
			// Payment has been successful
			$customer_order->add_order_note( __( 'azteca360 payment completed.', 'azteca360-gategay' ) . ' Ticket: ' . $transaction->getTicketNumber() );

			apply_filters( 'woocommerce_payment_complete_order_status', $customer_order->update_status( 'completed' ) );

			// Empty the cart (Very important step)
			wc_empty_cart();

			// Redirect to thank you page
			return array(
				'result'   => 'success',
				'redirect' => $this->get_return_url( $customer_order ),
			);
		} else {
			// Transaction was not succesful
			// Add notice to the cart
			WC()->session->set( 'reload_checkout', true );
			wc_add_notice( "Error " . $transaction->getResponseCode() . ": " . $transaction->getResponseText(), 'error' );
			// Add note to the order for your reference
			WC()->session->set( 'reload_checkout', false );

			return $customer_order->add_order_note( "Error " . $transaction->getResponseCode() . ": " . $transaction->getResponseText() );
		}
	}

	public function build_contact_details($customer_order){

        return array("email" => $customer_order->billing_email);
    }

	public function payment_scripts() {


		if ( $this->environment === 'no' ) {
			wp_enqueue_script( 'azteca360-prod-public.js', plugin_dir_url( __FILE__ ) . '/js/azteca360-prod-public.js', array( 'jquery' ), null, false );
		}
		else{
			wp_enqueue_script( 'azteca360-public.js', plugin_dir_url( __FILE__ ) . '/js/azteca360-public.js', array( 'jquery' ), null, false );
		}

	}

	public function form() {
		global $woocommerce;

		if ( ! $this->public_id || ! $this->private_id ) {
			echo '<p> Error en la configuración </p>';
		} else {
			echo '<fieldset id="wc-' . esc_attr( $this->id ) . '-cc-form" class=\'wc-credit-card-form wc-payment-form\'>';
			do_action( 'woocommerce_credit_card_form_start', $this->id );
			echo '<div id="azteca360-payment-form"></div>';
			do_action( 'woocommerce_credit_card_form_end', $this->id );
			echo $this->render_cajita( $woocommerce->cart->total );
			echo '<div class="clear"></div>  </fieldset>';
			echo '<script src="http://10.112.165.20:9090/azteca360.min.js"></script>';
		}
	}

	public function render_cajita( $total ) {

		return '<script type="text/javascript">
						var form = jQuery(\'#azteca360-payment-form\');
						var place_order_button = jQuery(\'#place_order\');
					
						    var azteca360 = new azteca360Checkout(
		                    {
		                    "form": "azteca360-payment-form",
		                    "merchant_id": \'' . $this->public_id . '\',
							"color": \'' . $this->color . '\',
		                    "amount": \'' . number_format( $total, 2 ) . '\',
		                    "currency": \'' . get_woocommerce_currency() . '\',
		                    "is_subscription": false
		                    });
						
		                	if(form.closest(".payment_box.payment_method_azteca360").css(\'display\') === \'block\'){
                				place_order_button.hide();
            				}
            				form.closest(".payment_box.payment_method_azteca360").bind("show", function() {
                				place_order_button.hide();
            				});

            				form.closest(".payment_box.payment_method_azteca360").bind("hide", function() {
                				place_order_button.show();
            				});
                			
		            </script>';

	}

	public function validate_fields()
	{
		WC()->session->set( 'reload_checkout', true);
		return true;
	}

}

?>