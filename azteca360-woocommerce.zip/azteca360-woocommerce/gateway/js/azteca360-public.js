(function ($) {
    'use strict';

    

})(jQuery);

var azteca360Checkout, bind = function (e, t) {
    return function () {
        return e.apply(t, arguments)
    }
};
azteca360Checkout = function () {
    function azteca360(e, t) {
        this.params = null != e ? e : {};
        this.onReceiveMessage = bind(this.onReceiveMessage, this);
        this.url = t || "http://10.51.145.76:8383/getToken";
        this.id = +new Date;
        this.iframeHeightOffset = 12;
        this.element = document.getElementById(this.params.form);
        
        Azteca360 
        .createPayment(this.params.form, { 
            hidePaymentMenu: false,
            methodDefault: 'card',
            getAuthentication: this.getAuthentication, 
            styles: { 
            container: { 
             //   color: 'dark', 
               // fontFamily: 'monospace', 
              //  backgroundColor: this.params.color 
            }, 
            }, 
        }) 
        .then((payment) => { 
        console.log(payment)
 
         setTimeout(() => { 
           payment.updateStyles({ 
             container:{ 
               backgroundColor: this.params.color 
             } 
           }); 
         }, 3000); 6
 
            payment.onChange((payload) => { 
            console.log('iframe1'); 
            console.log(payload); 
            }); 
        });

        
    //    this.form = jQuery(this.element).closest("form");
      //  this.iframe = document.createElement("iframe");
      //  this.loadIframe();
        this.listenForMessages();
    }

    azteca360.prototype.getAuthentication = function() { 
        return fetch('http://10.51.145.76:8383/getToken',{
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            }
        })
        .then(response => response.json())
        .catch(error => console.error('Error:', error))
        .then(function(response) {
            return { access_token: response.resultado.access_token}
        })
      }

    azteca360.prototype.loadIframe = function () {
        var e, t, i, r;
        i = this.url + ("?merchant_id=" + this.params.merchant_id) + ("&is_subscription=" + this.params.is_subscription)  + ("&amount=" + this.params.amount) + ("&language=" + this.params.language) + ("&currency=" + this.params.currency);
        e = {
            src: i,
            width: "100%",
            style: "display:",
            name: "azteca360-iframe",
            id: this.id,
            scrolling: "yes",
            frameborder: "0"
        };
        for (t in e) {
            r = e[t];
            this.iframe.setAttribute(t, r);
        }

        return this.element.appendChild(this.iframe)
    };

    azteca360.prototype.listenForMessages = function () {
        return window.addEventListener("message", this.onReceiveMessage, !1)
    };

    azteca360.prototype.onReceiveMessage = function (e) {
        console.log(e.data)
        if (e.origin === this.expectedOrigin())return this.processMessage(e.data)
    };

    azteca360.prototype.expectedOrigin = function () {
        var e;
        return e = this.url.split("/"), e[0] + "//" + e[2]
    };

    azteca360.prototype.adjustHeight = function (e) {
        return this.iframe.height = this.iframeHeightOffset + parseInt(e, 50)
    };

    azteca360.prototype.setParameters = function (e) {
        var t, i, r, s, n;
        s = e.split(",");
        n = s[0];
        t = s[1];
        r = this.createInput(n, "azteca360Token");
        i = this.createInput(t, "azteca360Deferred");
        this.form[0].appendChild(r);
        this.form[0].appendChild(i);
        this.form.submit();
        return s;
    };

    azteca360.prototype.createInput = function (e, t) {
        var i, r, s, n;
        r = document.createElement("input"), i = {type: "hidden", name: t, value: e.trim()};
        for (s in i)n = i[s], r.setAttribute(s, n);
        return r
    };

    azteca360.prototype.processMessage = function (e) {
        var t, i, r;
        switch (r = e.split(":"), i = r[0], t = r[1], i) {
            case"height":
                return this.adjustHeight(t);
            case"parameters":
                return this.setParameters(t)
        }
    };

    return azteca360;
}();

// azteca360Version 201

